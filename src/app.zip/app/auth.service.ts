import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  users = [
    {
      username: 'user1',
      password: 'pass1',
      url: 'https://www.pizzahut.co.id/assets/images/digital_menu/phr/menu/pasta-rice/Classic-Fettuccine-With-Crispy-Chicken.png',
    },
    {
      username: 'user2',
      password: 'pass2',
      url: 'https://www.pizzahut.co.id/assets/images/digital_menu/phr/menu/pasta-rice/Classic-Fettuccine-With-Crispy-Chicken.png',
    },
    {
      username: 'user3',
      password: 'pass3',
      url: 'https://www.pizzahut.co.id/assets/images/digital_menu/phr/menu/pasta-rice/Classic-Fettuccine-With-Crispy-Chicken.png',
    },
  ];

  authenticate(username: string, password: string): boolean {
    // Check if the provided username and password match any user's credentials
    const user = this.users.find((u) => u.username === username && u.password === password);

    return !!user; // Return true if a match is found, otherwise false
  }
}
